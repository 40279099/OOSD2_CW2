﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Business;
using Data;

namespace Presentation
{
    /// <summary>
    /// Interaction logic for CreateTrain.xaml
    /// </summary>
    public partial class CreateTrain : Window
    {
        
        public CreateTrain()
        {
            InitializeComponent();
            grdStops.Visibility = Visibility.Hidden;
        }

        Train newTrain = new Train();
        Store store = new Store();

        private void chkDar_Checked(object sender, RoutedEventArgs e)
        {
            for (int i = 0; newTrain.stops[i].ToString().Contains("Darlington"); i++)
            {
                if (newTrain.stops[i].ToString() == "")
                {
                    newTrain.stops[i] = "Darlington";
                }
            }


        }

        private void chkYrk_Checked(object sender, RoutedEventArgs e)
        {
            for (int i = 0; newTrain.stops[i].ToString().Contains("York"); i++)
            {
                if (newTrain.stops[i].ToString() == "")
                {
                    newTrain.stops[i] = "York";
                }
            }
        }

        private void chkPbo_Checked(object sender, RoutedEventArgs e)
        {
            for (int i = 0; newTrain.stops[i].ToString().Contains("Petersborough"); i++)
            {
                if (newTrain.stops[i].ToString() == "")
                {
                    newTrain.stops[i] = "Petersborough";
                }
            }
        }

        private void chkNcl_Checked(object sender, RoutedEventArgs e)
        {
            for (int i = 0; newTrain.stops[i].ToString().Contains("Newcastle"); i++)
            {
                if (newTrain.stops[i].ToString() == "")
                {
                    newTrain.stops[i] = "Newcastle";
                }
            }
        }


        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                newTrain.t_ID = txtT_ID.ToString();
                newTrain.dep_stn = txtDepStn.ToString();
                newTrain.dep_date = DateTime.Parse(dtpDep.ToString());
                newTrain.dep_time = DateTime.Parse(txtDepTime.ToString());
                newTrain.arr_stn = txtArrStn.ToString();
                newTrain.arr_date = DateTime.Parse(dtpArr.ToString());
                newTrain.arr_time = DateTime.Parse(txtArrTime.ToString());

                if (chkFirst.IsChecked == true)
                {
                    newTrain.first_class = true;
                }
                else
                {
                    newTrain.first_class = false;
                }

                DateTime Slpr_time = new DateTime();
                Slpr_time = Convert.ToDateTime("21:00:00 PM");
                if (DateTime.Compare(Convert.ToDateTime(txtDepTime.ToString()), Slpr_time) > 0 && rdoSlpr.IsChecked == true)
                {
                    newTrain.type = "Sleeper";

                }
                else { MessageBox.Show("Error must be after 21:00"); }

                if (rdoStop.IsChecked == true)
                {
                    newTrain.type = "Stopping";

                }

                if (rdoExpress.IsChecked == true)
                {
                    newTrain.type = "Express";
                }
            }
            catch (Exception except)
            {

                MessageBox.Show(except.Message);
            }
            

            store.trainAdd(newTrain);
        }

        private void rdoStop_Checked(object sender, RoutedEventArgs e)
        {
            grdStops.Visibility = Visibility.Visible;
        }

        private void rdoSlpr_Checked(object sender, RoutedEventArgs e)
        {
            grdStops.Visibility = Visibility.Visible;
        }

        private void rdoExpress_Checked(object sender, RoutedEventArgs e)
        {
            grdStops.Visibility = Visibility.Hidden;
        }
    }
}
