﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business;

namespace Data
{
    public class Store
    {
        private List<Train> trainStore = new List<Train>();
        private List<Passenger> passStore = new List<Passenger>();

        public void trainAdd(Train newTrain)
        {
            foreach(Train t in trainStore)
            {
                if (!trainStore.Contains(t))
                {
                    trainStore.Add(newTrain);
                }
                else
                {
                    throw new ArgumentException("This train journey already exists.");
                }
            }
        }

        public Train trainFind(string t_ID)
        {
            foreach(Train t in trainStore)
            {
                if(t_ID == t.t_ID)
                {
                    return t;
                }

            }
            return null;
        }

        public void trainDel(string t_id)
        {
            Train t = this.trainFind(t_id);
            if(t!= null)
            {
                trainStore.Remove(t);
            }
        }

        public void passAdd(Passenger newPass)
        {
            foreach(Passenger p in passStore)
            {
                if (!passStore.Contains(p))
                {
                    passStore.Add(newPass);
                }
                else
                {
                    throw new ArgumentException("This booking has already been made.");
                }
            }
        }

        public Passenger passFind(string pass_ID)
        {
            foreach(Passenger p in passStore)
            {
                if(pass_ID.Equals( p.pass_Id))
                {
                    return p;
                }
            }
            return null;
        }

        public void passDel(string pass_ID)
        {
            Passenger p = this.passFind(pass_ID);
            if(p!= null)
            {
                passStore.Remove(p);
            }
        }
    }
}
