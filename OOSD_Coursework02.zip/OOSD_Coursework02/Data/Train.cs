﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class Train
    {
        public string t_ID;
        public string dep_stn;
        public string arr_stn;
        public DateTime dep_time = new DateTime();
        public DateTime arr_time = new DateTime();
        public DateTime dep_date = new DateTime();
        public DateTime arr_date = new DateTime();
        public bool first_class;
        public string type;
        public string[] stops = new string[4];

        private string T_ID
        {
            get
            {
                return t_ID;
            }

            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    Exception except01 = new Exception();
                }
                t_ID = value;
            }
        }


        private string Dep_Stn
        {
            get
            {
                return dep_stn;
            }

            set
            {
                dep_stn = value;
            }
        }

        private string Arr_Stn
        {
            get
            {
                return arr_stn;
            }

            set
            {
                arr_stn = value;
            }
        }

        private DateTime Dep_Time
        {
            get
            {
                return dep_time;
            }

            set
            {
                dep_time = value;
            }
        }

        private DateTime Arr_Time
        {
            get
            {
                return arr_time;
            }

            set
            {
                arr_time = value;
            }
        }

        private DateTime Dep_Date
        {
            get
            {
                return dep_date;
            }

            set
            {
                dep_date = value;
            }
        }

        private DateTime Arr_Date
        {
            get
            {
                return arr_date;
            }

            set
            {
                arr_date = value;
            }
        }

        private bool First
        {
            get
            {
                return first_class;
            }

            set
            {
                first_class = value;
            }
        }

        private String Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }

        private String[] Stops
        {
            get
            {
                return stops;
            }

            set
            {
                for (int i = 0; i < 4; i++)
                {
                    stops[i] = value.ToString();
                }
            }
        }
    }
}


