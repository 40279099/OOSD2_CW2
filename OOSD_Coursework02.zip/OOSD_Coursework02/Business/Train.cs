﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class Train
    {
        public string t_ID;
        public string dep_stn;
        public string arr_stn;
        public DateTime dep_time = new DateTime();
        public DateTime arr_time = new DateTime();
        public DateTime dep_date = new DateTime();
        public DateTime arr_date = new DateTime();
        public bool first_class;
        public string type;
        public string[] stops = new string[4];

        private string T_ID
        {
            get
            {
                return t_ID;
            }

            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Please enter the train ID.");
                }
                t_ID = value;
            }
        }


        private string Dep_Stn
        {
            get
            {
                return dep_stn;
            }

            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Please enter the departure station.");
                }
                dep_stn = value;
            }
        }

        private string Arr_Stn
        {
            get
            {
                return arr_stn;
            }

            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Please enter the arrival station.");
                }
                arr_stn = value;
            }
        }

        private DateTime Dep_Time
        {
            get
            {
                return dep_time;
            }

            set
            {
                if (value == null)
                {
                    throw new ArgumentException("Please select a departure time.");
                }
                dep_time = value;
            }
        }

        private DateTime Arr_Time
        {
            get
            {
                return arr_time;
            }

            set
            {
                if (value == null)
                {
                    throw new ArgumentException("Please select an arrival time.");
                }
                arr_time = value;
            }
        }

        private DateTime Dep_Date
        {
            get
            {
                return dep_date;
            }

            set
            {
                if (value == null)
                {
                    throw new ArgumentException("Please select a departure date.");
                }
                dep_date = value;
            }
        }

        private DateTime Arr_Date
        {
            get
            {
                return arr_date;
            }

            set
            {
                if (value == null)
                {
                    throw new ArgumentException("Please select an arrival date.");
                }
                arr_date = value;
            }
        }

        private bool First
        {
            get
            {
                return first_class;
            }

            set
            {
                first_class = value;
            }
        }

        private string Type
        {
            get
            {
                return type;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Please select  the train's type.");
                }
                type = value;
            }
        }

        private String[] Stops
        {
            get
            {
                return stops;
            }

            set
            {
                for (int i = 0; i < 4; i++)
                {
                    stops[i] = value.ToString();
                }
            }
        }
    }
}


