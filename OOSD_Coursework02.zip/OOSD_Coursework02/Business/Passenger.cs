﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class Passenger
    {
        public string name;
        public string t_ID;
        public string dep_stn;
        public string arr_stn;
        public bool first;
        public bool cabin;
        public char coach;
        public int seat;
        public string pass_Id;

        private string Name
        {
            get
            {
                return name;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Please enter the passengers name.");
                }
                name = value;
            }
        }

        private string T_Id
        {
            get
            {
                return t_ID;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Please enter the train's ID.");
                }
                t_ID = value;
            }
        }

        private string Dep_Stn
        {
            get
            {
                return dep_stn;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Please enter the departure station.");
                }
                dep_stn = value;
            }

        }

        private string Arr_Stn
        {
            get
            {
                return arr_stn;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Please enter the arrival station.");
                }
            }
        }

        private bool First
        {
            get
            {
                return first;
            }
            set
            {
                first = value;
            }
        }

        private bool Cabin
        {
            get
            {
                return cabin;
            }
            set
            {
                cabin = value;
            }
        }

        private char Coach
        {
            get
            {
                return coach;
            }
            set
            {
                if (char.IsLetter(value))
                {
                    coach = value;
                }
                else
                {
                    throw new ArgumentException("Please enter a coach between A-H.");
                }
            }
        }

        private int Seat
        {
            get
            {
                return seat;
            }
            set
            {
                if(value<0 || value> 60)
                {
                    throw new ArgumentException("Please enter a valid seat number between 1 and 60.");
                }
            }
        }

        private string Pass_ID
        {
            get
            {
                return pass_Id;
            }
            set
            {
                pass_Id = string.Join(name.Substring(0, 3), t_ID);
            }
        }
    }
}
